


@extends('admin.layout.app')
@section('contain')

    <!--App-Content-->
    <div class="app-content my-3 my-md-5">
        <div class="side-app">
            <div class="page-header">
                <h4 class="page-title">Dashboard 1</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Dashboard 1</li>
                </ol>
            </div>

            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3 ">
                    <div class="card overflow-hidden">
                        <div class="card-header">
                            <h3 class="card-title">Total Students</h3>
                            <div class="card-options"> <a class="btn btn-sm btn-primary" href="#">View</a> </div>
                        </div>
                        <div class="card-body ">
                            <h2 class="text-dark  mt-0 font-weight-bold">4,657</h2>
                            <div class="progress progress-sm mt-0 mb-2">
                                <div class="progress-bar bg-primary w-75" role="progressbar"></div>
                            </div>
                            <div class=""><i class="fa fa-caret-up text-green mr-1"></i>10% than last year</div>
                        </div>
                    </div>
                </div>
                <div class=" col-sm-12 col-md-6 col-lg-6 col-xl-3">
                    <div class="card overflow-hidden">
                        <div class="card-header">
                            <h3 class="card-title">New Students</h3>
                            <div class="card-options"> <a class="btn btn-sm btn-secondary" href="#">View</a> </div>
                        </div>
                        <div class="card-body ">
                            <h2 class="text-dark  mt-0 font-weight-bold">2,592</h2>
                            <div class="progress progress-sm mt-0 mb-2">
                                <div class="progress-bar bg-secondary w-45" role="progressbar"></div>
                            </div>
                            <div class=""><i class="fa fa-caret-down text-danger mr-1"></i>12% than last year</div>
                        </div>
                    </div>
                </div>
                <div class=" col-sm-12 col-md-6 col-lg-6 col-xl-3">
                    <div class="card overflow-hidden">
                        <div class="card-header">
                            <h3 class="card-title">Total Graduates</h3>
                            <div class="card-options"> <a class="btn btn-sm btn-warning" href="#">View</a> </div>
                        </div>
                        <div class="card-body ">
                            <h2 class="text-dark  mt-0 font-weight-bold">3,517</h2>
                            <div class="progress progress-sm mt-0 mb-2">
                                <div class="progress-bar bg-warning w-50" role="progressbar"></div>
                            </div>
                            <div class=""><i class="fa fa-caret-down text-danger mr-1"></i>5% than last year</div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3 ">
                    <div class="card overflow-hidden">
                        <div class="card-header">
                            <h3 class="card-title">Total Courses</h3>
                            <div class="card-options"> <a class="btn btn-sm btn-info" href="#">View</a> </div>
                        </div>
                        <div class="card-body ">
                            <h2 class="text-dark  mt-0  font-weight-bold">1,759</h2>
                            <div class="progress progress-sm mt-0 mb-2">
                                <div class="progress-bar bg-info w-25" role="progressbar"></div>
                            </div>
                            <div class=""><i class="fa fa-caret-up text-success mr-1"></i>15% than last year</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-8 col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Merit Overview</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-wrapper">
                                <canvas id="sales-status" class="chart-dropshadow"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Professors List</h3>
                        </div>
                        <div class="card-body">
                            <div class="activity">
                                <img src="../assets/images/users/male/24.jpg" alt="" class="img-activity">
                                <div class="time-activity">
                                    <div class="item-activity">
                                        <p class="mb-0"><b>Adam	Berry</b></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0">Web Designer</p>
                                            </div>
                                            <small class="mb-0 ml-auto"><b>Daily: 2Hours</b></small>
                                        </div>
                                    </div>
                                </div>
                                <img src="../assets/images/users/female/10.jpg" alt="" class="img-activity">
                                <div class="time-activity">
                                    <div class="item-activity">
                                        <p class="mb-0"><b>Irene Hunter</b></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0">3D Animation Trainer</p>
                                            </div>
                                            <small class="mb-0 ml-auto"><b>Daily: 3Hours</b></small>
                                        </div>
                                    </div>
                                </div>
                                <img src="../assets/images/users/male/4.jpg" alt="" class="img-activity">
                                <div class="time-activity">
                                    <div class="item-activity">
                                        <p class="mb-0"><b>John	Payne</b></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0">Digital Marketing</p>
                                            </div>
                                            <small class="mb-0 ml-auto"><b>Daily: 1Hours</b></small>
                                        </div>
                                    </div>
                                </div>
                                <img src="../assets/images/users/male/4.jpg" alt="" class="img-activity">
                                <div class="time-activity">
                                    <div class="item-activity">
                                        <p class="mb-0"><b>John	Payne</b></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0">Java Developer</p>
                                            </div>
                                            <small class="mb-0 ml-auto"><b>Daily: 2Hours</b></small>
                                        </div>
                                    </div>
                                </div>
                                <img src="../assets/images/users/female/8.jpg" alt="" class="img-activity">
                                <div class="time-activity mb-0">
                                    <div class="item-activity mb-0">
                                        <p class="mb-0"><b>Julia Hardacre</b></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0">App Developer</p>
                                            </div>
                                            <small class="mb-0 ml-auto"><b>Daily: 4Hours</b></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-3 col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Students Overview</h3>
                        </div>
                        <div class="card-body">
                            <div class="chats-wrap">
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Total Students</span>
                                        <span class="float-right p-1">100%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary w-100" ></div>
                                    </div>
                                </div>
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Good</span>
                                        <span class="float-right p-1">35%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-success w-35" ></div>
                                    </div>
                                </div>
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Satisfied</span>
                                        <span class="float-right p-1">75%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-info w-75"></div>
                                    </div>
                                </div>
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Excellent</span>
                                        <span class="float-right p-1">65%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-secondary w-65"></div>
                                    </div>
                                </div>
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Average</span>
                                        <span class="float-right p-1">40%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning w-40"></div>
                                    </div>
                                </div>
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Below Average</span>
                                        <span class="float-right p-1">35%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-indigo w-35"></div>
                                    </div>
                                </div>
                                <div class="chat-details p-2">
                                    <h6 class="mb-0">
                                        <span class="font-weight-normal">Unsatisfied</span>
                                        <span class="float-right p-1">20%</span>
                                    </h6>
                                    <div class="progress progress-sm mt-3">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-orange w-20"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12">
                    <div class="card overflow-hidden">
                        <div class="power-ribbon power-ribbon-top-left text-warning"><span class="bg-warning"><i class="fa fa-bolt"></i></span></div>
                        <div class="item-card7-img">
                            <div class="item-card7-imgs">
                                <a href="#"></a>
                                <img src="../assets/images/media/pictures/2.jpg" alt="img" class="cover-image">
                                <div class="item-tag">
                                    <h4  class="mb-0">$398.99</h4>
                                </div>
                            </div>
                            <div class="item-card7-icons">
                                <a href="#" class="item-card2-icons-l bg-black-trasparant"> <i class="fa fa-share-alt"></i></a>
                                <a href="#" class="item-card2-icons-l"> <i class="fa fa-heart-o"></i></a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="item-card7-desc">
                                <div class="item-card7-text mb-3">
                                    <a href="#" class="text-dark"><h4 class="mb-2">Coding Classes</h4></a>
                                </div>
                                <p class="">At vero eos et accusamus et iusto odio dignissimos ducimus </p>
                                <ul class="item-cards7-ic mb-0">
                                    <li><a href="#" class="icons"><i class="icon icon-location-pin mr-1"></i>  Los Angles</a></li>
                                    <li><a href="#" class="icons"><i class="icon icon-event  mr-1"></i> 5 hours ago</a></li>
                                    <li><a href="#" class="icons"><i class="icon icon-user text-muted mr-1"></i> Sally Peake</a></li>
                                    <li><a href="#" class="icons"><i class="icon icon-phone mr-1"></i> 567987087</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="item-card2-footer ">
                                <div class="item-card2-footer-u">
                                    <div class="row d-flex">
                                        <span class="review_score mr-2 badge badge-primary">4.0/5</span>
                                        <div class="rating-stars d-inline-flex">
                                            <input type="number" readonly="readonly" class="rating-value star" name="rating-stars-value" value="3">
                                            <div class="rating-stars-container">
                                                <div class="rating-star sm is--active">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm is--active">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm is--active">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div> (5 Reviews)
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12">
                    <div class="item">
                        <div class="card overflow-hidden mb-md-0">
                            <div class="item-card7-img">
                                <div class="item-card7-imgs">
                                    <a href="#"></a>
                                    <img src="../assets/images/media/pictures/18.jpg" alt="img" class="cover-image">
                                    <div class="item-tag">
                                        <h4  class="mb-0">$836.00</h4>
                                    </div>
                                </div>
                                <div class="item-card7-icons">
                                    <a href="#" class="item-card2-icons-l bg-black-trasparant"> <i class="fa fa-share-alt"></i></a>
                                    <a href="#" class="item-card2-icons-l"> <i class="fa fa-heart-o"></i></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="item-card7-desc">
                                    <div class="item-card7-text mb-3">
                                        <a href="#" class="text-dark"><h4 class="mb-2">3D Animation Trainig</h4></a>
                                    </div>
                                    <p class="">At vero eos et accusamus et iusto odio dignissimos ducimus </p>
                                    <ul class="item-cards7-ic mb-0">
                                        <li><a href="#" class="icons"><i class="icon icon-eye mr-1"></i> 22 Views</a></li>
                                        <li><a href="#" class="icons"><i class="icon icon-location-pin mr-1"></i> USA</a></li>
                                        <li><a href="#" class="icons"><i class="icon icon-event  mr-1"></i> 5 hours ago</a></li>
                                        <li><a href="#" class="icons"><i class="icon icon-phone mr-1"></i> 14 675 65430</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="item-card2-footer">
                                    <div class="item-card2-footer-u">
                                        <div class="row d-flex">
                                            <span class="review_score mr-2 badge badge-primary">4.0/5</span>
                                            <div class="rating-stars d-inline-flex">
                                                <input type="number" readonly="readonly" class="rating-value star" name="rating-stars-value" value="3">
                                                <div class="rating-stars-container">
                                                    <div class="rating-star sm is--active">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm is--active">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm is--active">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                </div> (5 Reviews)
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12">
                    <div class="item">
                        <div class="card overflow-hidden mb-xl-0">
                            <div class="item-card7-img">
                                <div class="item-card7-imgs">
                                    <a href="#"></a>
                                    <img src="../assets/images/media/pictures/10.jpg" alt="img" class="cover-image">
                                    <div class="item-tag">
                                        <h4  class="mb-0">$65.00</h4>
                                    </div>
                                </div>
                                <div class="item-card7-icons">
                                    <a href="#" class="item-card2-icons-l bg-black-trasparant"> <i class="fa fa-share-alt"></i></a>
                                    <a href="#" class="item-card2-icons-l text-primary"> <i class="fa fa-heart"></i></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="item-card7-desc">
                                    <div class="item-card7-text mb-3">
                                        <a href="#" class="text-dark"><h4 class="mb-2">Apps Development</h4></a>
                                    </div>
                                    <p class="">At vero eos et accusamus et iusto odio dignissimos ducimus </p>
                                    <ul class="item-cards7-ic mb-0">
                                        <li><a href="#" class="icons"><i class="icon icon-eye mr-1"></i> 22 Views</a></li>
                                        <li><a href="#" class="icons"><i class="icon icon-location-pin mr-1"></i> USA</a></li>
                                        <li><a href="#" class="icons"><i class="icon icon-event  mr-1"></i> 5 hours ago</a></li>
                                        <li><a href="#" class="icons"><i class="icon icon-phone mr-1"></i> 14 675 65430</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="item-card2-footer">
                                    <div class="item-card2-footer-u">
                                        <div class="row d-flex">
                                            <span class="review_score mr-2 badge badge-primary">4.0/5</span>
                                            <div class="rating-stars d-inline-flex">
                                                <input type="number" readonly="readonly" class="rating-value star" name="rating-stars-value" value="3">
                                                <div class="rating-stars-container">
                                                    <div class="rating-star sm is--active">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm is--active">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm is--active">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                </div> (5 Reviews)
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Todo List</h3>
                            <div class="card-options">
                                <a class="btn btn-sm btn-primary " href="#"><i class="fa fa-plus"></i> Add Task</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="custom-controls-stacked checklist-task">
                                <label class="custom-control custom-checkbox mb-3 checklist-desc">
                                    <input type="checkbox" class="custom-control-input" name="example-checkbox1" value="option1" checked="">
                                    <span class="custom-control-label">vero eos et accusamus et iusto odio dignissimos ducimus</span>
                                    <span class="check-data d-flex mt-1">
													<span class="text-muted">Completed 2h ago</span>
													<span class="check-icon ml-auto">
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="fa fa-pencil-square-o "></i> </span>
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Delete"><i class="fa fa-trash-o"></i></span>
													</span>
												</span>
                                </label>
                                <label class="custom-control custom-checkbox mb-3 checklist-desc">
                                    <input type="checkbox" class="custom-control-input" name="example-checkbox2" value="option2">
                                    <span class="custom-control-label"> et iusto odio dignissimos ducimus</span>
                                    <span class="check-data d-flex mt-1">
													<span class="text-muted">Completed 8h ago</span>
													<span class="check-icon ml-auto">
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="fa fa-pencil-square-o "></i> </span>
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Delete"><i class="fa fa-trash-o"></i></span>
													</span>
												</span>
                                </label>
                                <label class="custom-control custom-checkbox mb-3 checklist-desc">
                                    <input type="checkbox" class="custom-control-input" name="example-checkbox3" value="option3" checked="">
                                    <span class="custom-control-label"> eos  accusamus  iusto odio dignissimos </span>
                                    <span class="check-data d-flex mt-1">
													<span class="text-muted">Completed 4h ago</span>
													<span class="check-icon ml-auto">
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="fa fa-pencil-square-o "></i> </span>
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Delete"><i class="fa fa-trash-o"></i></span>
													</span>
												</span>
                                </label>
                                <label class="custom-control custom-checkbox checklist-desc">
                                    <input type="checkbox" class="custom-control-input" name="example-checkbox4" value="option4">
                                    <span class="custom-control-label">vet accusamus et iusto odio dignissimos </span>
                                    <span class="check-data d-flex mt-1">
													<span class="text-muted">Completed 5h ago</span>
													<span class="check-icon ml-auto">
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="fa fa-pencil-square-o "></i> </span>
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Delete"><i class="fa fa-trash-o"></i></span>
													</span>
												</span>
                                </label>
                                <label class="custom-control custom-checkbox mb-3 checklist-desc">
                                    <input type="checkbox" class="custom-control-input" name="example-checkbox2" value="option2">
                                    <span class="custom-control-label"> et iusto odio dignissimos ducimus</span>
                                    <span class="check-data d-flex mt-1">
													<span class="text-muted">Completed 8h ago</span>
													<span class="check-icon ml-auto">
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="fa fa-pencil-square-o "></i> </span>
														<span class="text-muted" data-toggle="tooltip" data-placement="top" data-original-title="Delete"><i class="fa fa-trash-o"></i></span>
													</span>
												</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-8">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Our Faculty</div>
                        </div>
                        <div class="card-body">
                            <div class="ibox teams mb-30 bg-boxshadow">
                                <!-- Ibox Content -->
                                <div class="ibox-content teams">
                                    <!-- Members -->
                                    <div class="avatar-list avatar-list-stacked">
                                        <span class="avatar brround cover-image cover-image" data-image-src="../assets/images/users/female/12.jpg" ></span>
                                        <span class="avatar brround cover-image cover-image" data-image-src="../assets/images/users/female/21.jpg" ></span>
                                        <span class="avatar brround cover-image cover-image" data-image-src="../assets/images/users/female/29.jpg"></span>
                                        <span class="avatar brround cover-image cover-image" data-image-src="../assets/images/users/female/2.jpg"></span>
                                        <span class="avatar brround cover-image cover-image" data-image-src="../assets/images/users/male/34.jpg"></span>
                                        <span class="avatar brround cover-image cover-image">+8</span>
                                    </div>
                                    <!-- Team Board Details -->
                                    <div class="teams-board-details mt-3">
                                        <h4 class="font-weight-semibold">About</h4>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam velit quisquam veniam excepturi. Contrary to popular belief, Lorem Ipsum is not simply random text classical Latin </p>
                                    </div>
                                    <!-- Progress Details -->
                                    <span class="font-weight-semibold">Status of current properties:</span>
                                    <div class="progress-details-teams mt-2 mb-4">
                                        <div class="stat-percent mb-2">58%</div>
                                        <div class="progress progress-sm ">
                                            <div class="progress-bar bg-primary w-50" role="progressbar"></div>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-4">
                                            <div class="teams-rank text-muted">Total Courses</div>
                                            <span>180</span>
                                        </div>
                                        <div class="col-4">
                                            <div class="teams-rank text-muted">Online Courses</div>
                                            <span>120</span>
                                        </div>
                                        <div class="col-4">
                                            <div class="teams-rank text-muted">Offline Courses</div>
                                            <span>156</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!--Footer-->
    <footer class="footer">
        <div class="container">
            <div class="row align-items-center flex-row-reverse">
                <div class="col-lg-12 col-sm-12 mt-3 mt-lg-0 text-center">
                    Copyright © 2019 <a href="#">Eudica</a>. Designed by <a href="#">Spruko</a> All rights reserved.
                </div>
            </div>
        </div>
@endsection

