<head>
		
		<!-- Bootstrap css -->
		<link href= {{ asset('plugins/bootstrap-4.3.1/css/bootstrap.min.css') }} rel="stylesheet" />

		<!-- Bootstrap Css -->
		<link href={{ asset('plugins/bootstrap-4.3.1/css/bootstrap.min.css') }} rel="stylesheet" />

		<!-- Dashboard css -->
		<link href={{ asset('css/style.css') }} rel="stylesheet" />
		<link href= {{ asset('assets/css/admin-custom.css') }} rel="stylesheet" />

		<!-- c3.js Charts Plugin -->
		<link href= {{ asset('plugins/charts-c3/c3-chart.css') }} rel="stylesheet" />

		<!---Font icons-->
		<link href= {{ asset('assets/css/icons.css') }} rel="stylesheet"/>

		<!-- Switcher css -->
		<link  href= {{ asset('switcher/css/switcher.css') }} rel="stylesheet" id="switcher-css" type="text/css" media="all"/>

		<!-- Color Skin css -->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href= {{ asset('color-skins/color6.css') }}  />

	</head>
