<script src= {{ asset('js/jquery-3.2.1.min.js') }}></script>

		<!-- Bootstrap js -->
		<script src={{ asset('plugins/bootstrap-4.3.1/js/popper.min.js') }}></script>
		<script src={{ asset('plugins/bootstrap-4.3.1/js/bootstrap.min.js') }}></script>

		<!--JQuery Sparkline Js-->
		<script src={{ asset('js/jquery.sparkline.min.js') }}></script>

		<!-- Circle Progress Js-->
		<script src={{ asset('js/circle-progress.min.js') }}></script>

		<!-- Star Rating Js-->
		<script src={{ asset('plugins/rating/jquery.rating-stars.js') }}></script>

		<!-- Custom scroll bar Js-->
		<script src={{ asset('plugins/pscrollbar/pscrollbar.js') }}></script>
		<script src={{ asset('plugins/pscrollbar/pscroll.js') }}></script>

		<!-- Fullside-menu Js-->
		<script src={{ asset('plugins/sidemenu/sidemenu.js') }}></script>

		<!--Counters -->
		<script src={{ asset('plugins/counters/counterup.min.js') }}></script>
		<script src={{ asset('plugins/counters/waypoints.min.js') }}></script>

		<!-- Custom Js-->
		<script src={{ asset('js/admin-custom.js') }}></script>

	</body>

</html>