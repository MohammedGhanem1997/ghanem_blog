


<h1>Email Verification Mail</h1>
Please verify your email with bellow link:
<a href="{{ route('verify-account', $token) }}">Verify Email</a>
