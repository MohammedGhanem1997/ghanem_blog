
<!DOCTYPE html>
@if ( app()->getLocale()== 'ar' )
    <html  lang="ar" dir="rtl"    >

@else
    <html  lang="en"  dir="ltr"  >

@endif
@include('layout.include.head')
<body>

    @yield('contain')
@include('layout.include.footer')
</html>
