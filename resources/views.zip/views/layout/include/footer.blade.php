<script src= {{ asset('js/jquery-3.2.1.min.js') }}></script>

		<!-- Bootstrap js -->
		<script src={{ asset('plugins/bootstrap-4.3.1/js/popper.min.js') }}></script>
		<script src={{ asset('plugins/bootstrap-4.3.1/js/bootstrap.min.js') }}></script>

		<!--JQuery Sparkline Js-->
		<script src={{ asset('js/jquery.sparkline.min.js') }}></script>

		<!-- Circle Progress Js-->
		<script src={{ asset('js/circle-progress.min.js') }}></script>

		<!-- Star Rating Js-->
		<script src={{ asset('plugins/rating/jquery.rating-stars.js') }}></script>

		<!-- Custom scroll bar Js-->
		<script src={{ asset('plugins/pscrollbar/pscrollbar.js') }}></script>
		<script src={{ asset('plugins/pscrollbar/pscroll.js') }}></script>

		<!-- Fullside-menu Js-->
		<script src={{ asset('plugins/sidemenu/sidemenu.js') }}></script>

		<!--Counters -->
		<script src={{ asset('plugins/counters/counterup.min.js') }}></script>
		<script src={{ asset('plugins/counters/waypoints.min.js') }}></script>

		<!-- Custom Js-->
		<script src={{ asset('js/admin-custom.js') }}></script>

{{--firebase--}}
<script src="https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js"></script>
<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.0/firebase-analytics.js"></script>
<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.0/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.0/firebase-storage.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

<script src={{ asset('js/firebase/init.js')}}></script>
<script src={{ asset('js/firebase/emailverification.js')}}></script>
<script src={{ asset('js/firebase/phoneverification.js')}}></script>

	</body>

</html>
